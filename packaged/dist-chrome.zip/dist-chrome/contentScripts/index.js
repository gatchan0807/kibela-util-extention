(() => {
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __esm = (fn, res) => function __init() {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  };
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // src/features/target-blank/contentScripts/domAdapter.ts
  var domElements, allATag, setTargetBlankAttribute;
  var init_domAdapter = __esm({
    "src/features/target-blank/contentScripts/domAdapter.ts"() {
      domElements = [];
      allATag = document.querySelectorAll(".markdown-body a[href]");
      setTargetBlankAttribute = (element) => {
        element.setAttribute("target", "_blank");
        element.setAttribute("rel", "noopener noreferrer");
      };
      allATag.forEach((e) => {
        var _a, _b, _c, _d;
        const className = (_a = e.getAttribute("class")) != null ? _a : "";
        const isAnchorLink = className.includes("anchor");
        const isUserMention = className.includes("user-mention");
        const isSameSiteLink = className.includes("entry-titleWithIcon");
        domElements.push({
          href: (_b = e.getAttribute("href")) != null ? _b : "",
          className: (_c = e.getAttribute("class")) != null ? _c : "",
          idName: (_d = e.getAttribute("id")) != null ? _d : "",
          hasTargetBlank: e.getAttribute("target") === "_blank",
          isSameSiteLink,
          isUserMention,
          isAnchorLink,
          setTargetBlankAttribute,
          rawElement: e
        });
      });
    }
  });

  // src/features/target-blank/contentScripts/setTargetBlank.ts
  var setTargetBlank;
  var init_setTargetBlank = __esm({
    "src/features/target-blank/contentScripts/setTargetBlank.ts"() {
      init_domAdapter();
      setTargetBlank = (settings) => {
        const excludeUrlList = settings.excludeUrlList.map((excludeUrl) => excludeUrl.host);
        domElements.forEach((element) => {
          if (!settings.alwaysOpenOtherTab) {
            return;
          }
          if (settings.inKibelaLinkOpenSameTab && (element.isUserMention || element.isSameSiteLink)) {
            return;
          }
          if (element.isAnchorLink) {
            return;
          }
          try {
            const { host } = new URL(element.href);
            if (excludeUrlList.includes(host)) {
              return;
            }
          } catch (e) {
            console.log(e);
          }
          element.setTargetBlankAttribute(element.rawElement);
        });
      };
    }
  });

  // src/features/target-blank/contentScripts/index.ts
  var init_contentScripts = __esm({
    "src/features/target-blank/contentScripts/index.ts"() {
      init_domAdapter();
      init_setTargetBlank();
    }
  });

  // src/features/target-blank/utils/getSettingsAboutTargetBlank.ts
  var getSettingsAboutTargetBlank;
  var init_getSettingsAboutTargetBlank = __esm({
    "src/features/target-blank/utils/getSettingsAboutTargetBlank.ts"() {
      getSettingsAboutTargetBlank = () => {
        return new Promise((resolve) => {
          chrome.storage.sync.get("targetBlankSettings", (rawResult) => {
            var _a, _b, _c;
            const { targetBlankSettings } = rawResult;
            const result = targetBlankSettings ? {
              alwaysOpenOtherTab: (_a = targetBlankSettings.alwaysOpenOtherTab) != null ? _a : false,
              inKibelaLinkOpenSameTab: (_b = targetBlankSettings.inKibelaLinkOpenSameTab) != null ? _b : false,
              excludeUrlList: (_c = targetBlankSettings.excludeUrlList) != null ? _c : []
            } : {
              alwaysOpenOtherTab: false,
              inKibelaLinkOpenSameTab: false,
              excludeUrlList: []
            };
            return resolve(result);
          });
        });
      };
    }
  });

  // src/contentScripts/index.ts
  var require_contentScripts = __commonJS({
    "src/contentScripts/index.ts"(exports) {
      init_contentScripts();
      init_getSettingsAboutTargetBlank();
      (() => __async(exports, null, function* () {
        console.log("Running \u6728\u3079\u3089\uFF01\uFF01 on feature of TargetBlank");
        const settings = yield getSettingsAboutTargetBlank();
        yield setTargetBlank(settings);
      }))();
    }
  });
  require_contentScripts();
})();
