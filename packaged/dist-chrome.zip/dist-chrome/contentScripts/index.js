(() => {
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __esm = (fn, res) => function __init() {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  };
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // src/features/target-blank/contentScripts/domAdapter.ts
  var SELECTOR, convertDomElement, getPreviewObserver;
  var init_domAdapter = __esm({
    "src/features/target-blank/contentScripts/domAdapter.ts"() {
      SELECTOR = {
        main: ".markdown-body a[href]",
        preview: ".previewBox .markdown-body a[href]",
        previewWrapper: ".previewBox > div"
      };
      convertDomElement = (elementList) => {
        const temporaryList = [];
        elementList.forEach((e) => {
          var _a, _b, _c, _d;
          const className = (_a = e.getAttribute("class")) != null ? _a : "";
          const isAnchorLink = className.includes("anchor");
          const isUserMention = className.includes("user-mention");
          const isSameSiteLink = className.includes("entry-titleWithIcon");
          temporaryList.push({
            href: (_b = e.getAttribute("href")) != null ? _b : "",
            className: (_c = e.getAttribute("class")) != null ? _c : "",
            idName: (_d = e.getAttribute("id")) != null ? _d : "",
            hasTargetBlank: e.getAttribute("target") === "_blank",
            isSameSiteLink,
            isUserMention,
            isAnchorLink,
            rawElement: e,
            setTargetBlankAttribute: (element) => {
              element.setAttribute("target", "_blank");
              element.setAttribute("rel", "noopener noreferrer");
            }
          });
        });
        return temporaryList;
      };
      getPreviewObserver = ({ settings, effectsDom: effectsDom2 }) => {
        return new MutationObserver((_) => {
          const rawElements = document.querySelectorAll(SELECTOR.preview);
          let elements = [];
          if (rawElements) {
            elements = convertDomElement(rawElements);
          }
          effectsDom2({ elements, settings });
        });
      };
    }
  });

  // src/features/target-blank/contentScripts/effectsDom.ts
  var effectsDom;
  var init_effectsDom = __esm({
    "src/features/target-blank/contentScripts/effectsDom.ts"() {
      effectsDom = ({ elements, settings }) => {
        const excludeUrlList = settings.excludeUrlList.map((excludeUrl) => excludeUrl.host);
        elements.forEach((element) => {
          if (!settings.alwaysOpenOtherTab) {
            return;
          }
          if (settings.inKibelaLinkOpenSameTab && (element.isUserMention || element.isSameSiteLink)) {
            return;
          }
          if (element.isAnchorLink) {
            return;
          }
          try {
            const href = element.isUserMention || element.isSameSiteLink ? `${location.origin}${element.href}` : element.href;
            const { host } = new URL(href);
            if (excludeUrlList.includes(host)) {
              return;
            }
          } catch (e) {
            console.error("Caused URL:", element.href);
            console.error(e);
          }
          element.setTargetBlankAttribute(element.rawElement);
        });
      };
    }
  });

  // src/features/target-blank/contentScripts/setTargetBlank.ts
  var setTargetBlank;
  var init_setTargetBlank = __esm({
    "src/features/target-blank/contentScripts/setTargetBlank.ts"() {
      init_domAdapter();
      init_effectsDom();
      setTargetBlank = (settings) => {
        const rawElements = document.querySelectorAll(SELECTOR.main);
        let elements = [];
        if (rawElements) {
          elements = convertDomElement(rawElements);
        }
        effectsDom({ elements, settings });
      };
    }
  });

  // src/features/target-blank/contentScripts/index.ts
  var init_contentScripts = __esm({
    "src/features/target-blank/contentScripts/index.ts"() {
      init_domAdapter();
      init_setTargetBlank();
    }
  });

  // src/features/target-blank/contentScripts/startPreviewBoxObserve.ts
  var startPreviewBoxObserve;
  var init_startPreviewBoxObserve = __esm({
    "src/features/target-blank/contentScripts/startPreviewBoxObserve.ts"() {
      init_domAdapter();
      init_effectsDom();
      startPreviewBoxObserve = (settings) => {
        const previewBox = document.querySelector(SELECTOR.previewWrapper);
        if (previewBox) {
          const observer = getPreviewObserver({ settings, effectsDom });
          observer.observe(previewBox, {
            childList: true,
            subtree: true
          });
        }
      };
    }
  });

  // src/features/target-blank/utils/getSettingsAboutTargetBlank.ts
  var getSettingsAboutTargetBlank;
  var init_getSettingsAboutTargetBlank = __esm({
    "src/features/target-blank/utils/getSettingsAboutTargetBlank.ts"() {
      getSettingsAboutTargetBlank = () => {
        return new Promise((resolve) => {
          chrome.storage.sync.get("targetBlankSettings", (rawResult) => {
            var _a, _b, _c, _d;
            const { targetBlankSettings } = rawResult;
            const result = targetBlankSettings ? {
              alwaysOpenOtherTab: (_a = targetBlankSettings.alwaysOpenOtherTab) != null ? _a : true,
              inKibelaLinkOpenSameTab: (_b = targetBlankSettings.inKibelaLinkOpenSameTab) != null ? _b : false,
              isOpenOtherTabInPreview: (_c = targetBlankSettings.isOpenOtherTabInPreview) != null ? _c : true,
              excludeUrlList: (_d = targetBlankSettings.excludeUrlList) != null ? _d : []
            } : {
              alwaysOpenOtherTab: true,
              inKibelaLinkOpenSameTab: false,
              isOpenOtherTabInPreview: true,
              excludeUrlList: []
            };
            return resolve(result);
          });
        });
      };
    }
  });

  // src/contentScripts/index.ts
  var require_contentScripts = __commonJS({
    "src/contentScripts/index.ts"(exports) {
      init_contentScripts();
      init_startPreviewBoxObserve();
      init_getSettingsAboutTargetBlank();
      (() => __async(exports, null, function* () {
        console.log("Running \u6728\u3079\u3089\uFF01\uFF01 on feature of TargetBlank");
        const settings = yield getSettingsAboutTargetBlank();
        if (settings.isOpenOtherTabInPreview) {
          startPreviewBoxObserve(settings);
        }
        yield setTargetBlank(settings);
      }))();
    }
  });
  require_contentScripts();
})();
